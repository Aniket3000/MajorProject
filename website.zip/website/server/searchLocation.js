require('dotenv').config();
const express = require('express');
const axios=require('axios');
const app=express();
const cors=require('cors');
const bodyParser=require('body-parser');
const mysql = require('mysql2');
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: process.env.SQL_PASSWORD,
    database: "login"
});
con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({extended:true}));

app.get('/searching/:search', function (req, res) {
    const searched=req.params.search.toLowerCase();
    con.query('SELECT * FROM locations WHERE state=(?)', [searched], function (err, result) {
        if (err) console.log(err);
        res.send(result);
    })
}).listen('8080');
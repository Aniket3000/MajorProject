import React, { useState } from 'react';
import "../static/1.jpeg";
import Axios from 'axios';
import "../static/home.css";
export default function Home() {
  const [search, changeSearch] = useState('');
  const [searchResult, changeResult] = useState();
  const [nor, changeNor] = useState(-1);
  const onSubmit = () => {
    Axios.get(`http://localhost:8080/searching/${search}`, (err) => {
      console.log(err);
    }).then((response) => {
      console.log(response.data);
      changeNor(response.data.length);
      // console.log("nor:" + nor);
      changeResult(response.data);
    });
  }
  return (
    <>
    <div className='bg total'>
      {/* <form>
        <div className="mb-3 mx-3">
          <label for="exampleInputEmail1" className="form-label">Email address</label>
          <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
        </div>
        <div className="mb-3 mx-3">
          <label for="exampleInputPassword1" className="form-label">Password</label>
          <input type="password" className="form-control" id="exampleInputPassword1" />
        </div>
        <div className="mb-3 mx-3 form-check">
          <input type="checkbox" className="form-check-input" id="exampleCheck1" />
          <label className="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" className="mx-3 btn btn-primary">Submit</button>
      </form> */}
      <div className="my-5">
        <div className="form-outline mx-auto my-4">
          <input type="search" id="form1" autoComplete='off' onChange={(e) => {
            changeSearch(e.target.value);
          }} onKeyDown={(e) => {
            if (e.key === 'Enter' && search!=='') {
              if (nor === 0) {
                changeNor(-1);
              }
              onSubmit();
            }
          }}
            className="form-control" placeholder='Search location' />
        </div>
        <button type="button" className="btn " onClick={onSubmit}><h5>Submit</h5></button>
      </div>
      <div className='my-3'>
        <ul>
          {(searchResult !== undefined) && (searchResult.map(searchResult => (
            <li>
              <div className="card my-3 mx-3">
                {/* <img src="..." className="card-img-top" alt="..." /> */}
                <div className="card-body">
                  <h5 className="card-title">{searchResult.city}</h5>
                  <p>state : {searchResult.state}</p>
                  <p>capacity : {searchResult.capacity}</p>
                  <p>Information on the facility in {searchResult.city}.</p>
                  {/* <a href="#" className="btn btn-primary">Go somewhere</a> */}
                </div>
              </div>
            </li>
          )))}
        </ul>
        {(nor === 0) && <h4 className="mx-4">No results</h4>}
      </div>
      </div>
    </>

  )
}

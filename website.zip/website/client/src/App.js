import './App.css';
import Navbar from './components/Navbar';
import { useState } from 'react';
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Link
} from "react-router-dom";
import TextForm from './components/TextForm';
import Home from './components/Home';

function App() {
  let name = "Welcome";
  const lightMode = {
    toggle_label_color: "text-dark bg-gray-dark",
    text: "Enable dark mode",
    time: "light"
  }
  const darkMode =
  {
    toggle_label_color: "text-light bg-dark",
    text: "Disable dark mode",
    time: "dark",

  }
  const [mode, setMode] = useState(lightMode)
  const toggleMode = () => {
    if (mode.time === lightMode.time) {
      setMode(darkMode);
      document.body.style.backgroundColor = "#1c1b30";
    }
    else {
      setMode(lightMode);
      document.body.style.backgroundColor = "white";
    }
  }
  return (
    <>
      <Router>
        <Navbar title={name} timeMode={mode} toggle={toggleMode} />
        <Routes>
          <Route path="/about" element={<TextForm heading="Tell us" timeMode={mode} />} />
          <Route path="" element={<Home/>} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
